const fs = require('fs')

exports.handler = (event, context, callback) => {
    var finish = function (err, html) {
        callback(null, {
            "isBase64Encoded": false,
            "statusCode": 200,
            "headers": { "Content-type": "text/html" },
            "body": html
        })
    }

    var filename = require.resolve(`./index.html`);
    
    fs.readFile(filename, 'utf8', finish)
}